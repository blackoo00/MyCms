export default {
    CATS_INIT: 'CATS_INIT',
    CATS_PAGE: 'CATS_PAGE'
}
