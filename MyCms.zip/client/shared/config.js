export default{
    STORESERVER:'http://z.cn/api/cms/',
    WORKERMANSERVER:'http://127.0.0.1:2120',
    WORKERMANLINK:'http://127.0.0.1:2121'
}
