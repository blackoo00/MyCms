export default {
    HOME_INIT: 'HOME_INIT'
}
