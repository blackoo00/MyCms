export default {
    MEMBER_INIT: 'MEMBER_INIT'
};
