export default{
    LOGIN: 'LOGIN',
    INPUTAC:'INPUTAC',
    INPUTSE:'INPUTSE'
}
